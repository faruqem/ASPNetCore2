﻿namespace AspNetVideoCore.Models
{
    public enum Genres
    {
        None,
        Animated,
        Horror,
        Comedy,
        Romance,
        Action
    }
}
